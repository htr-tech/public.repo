
![](https://raw.githubusercontent.com/EliverLara/juicy-syntax/master/images/logo.png)

![](https://raw.githubusercontent.com/EliverLara/juicy-syntax/master/images/juicy.png)

# Install

From the command line:

`apm install juicy-syntax`

If the command line isn't your thing:

- Go to **Settings > Install**
- Search for `juicy-syntax` and click **Install**
- Go to **Settings > Themes** and choose **Juicy** from the dropdown menu
