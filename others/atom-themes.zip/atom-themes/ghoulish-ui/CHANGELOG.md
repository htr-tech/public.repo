## Changelog ##

| Changes | Release |
| -- | -- |
| Readme update only | 1.1.3 |
| Fix disappearing scrollbars | 1.1.1 |
| Tree view custom background image setting added, [Tree view hover](https://github.com/atom/one-dark-ui/pull/263) added via upstream PR  | 1.1.0 |
| Residual code removed | 1.0.8 |
| Remove redundant code, Notification text color adjustment| 1.0.7 |
| Theme switch autoload bugfix | 1.0.5 |
| Various visual improvements & highlighting | 1.0.4 |
| Lighten super dark elements, Adjust glow over file type icons, Bugfix & colorized Git repo | 1.0.3 |
| File type icons added, Active tab color added, to differentiate windows, Tooltip & settings appearance enhancements | 1.0.0 |
| added additional screenshot | 0.4.0 |
| apm bugfix | 0.3.0 |
| Public beta release, Merged open PR from [dallinb](https://github.com/dallinb) into Ghoulish from Steam Pirate UI | 0.2.0 |
